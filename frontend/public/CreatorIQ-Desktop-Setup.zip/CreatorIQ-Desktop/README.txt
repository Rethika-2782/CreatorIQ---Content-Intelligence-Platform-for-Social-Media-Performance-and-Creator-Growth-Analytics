CreatorIQ Desktop Application Setup
Version: 2.0.0

1. Double-click CreatorIQ.bat to launch in desktop window mode.
2. Or open https://creatoriq-content-in-gbxclply.onslate.in/ and click Install App.